
%% *****************************%
% Original Local Binary Pattern (LBP) 
% feature extraction

% Input image (I1)
%% ******************************%
function LBP_feature=Original_LBP_func(I1)

I2=double(I1);
[m,n]=size(I2);
for i=2:m-1
    for j=2:n-1
         block(1:3,1:3)=I2(i-1:i+1,j-1:j+1)-I2(i,j)*ones(3,3);
         block1=block(:)';
         i1=1;
            for j1=1:9
                if block1(i1,j1)>=0
                    d1(i1,j1)=1;
                else
                    d1(i1,j1)=0;
                end 
            end
            LBP1(i,j)=d1(1,1)+2*d1(1,2)+4*d1(1,3)+8*d1(1,4)+16*d1(1,6)+32*d1(1,7)+64*d1(1,8)+128*d1(1,9);
    end
end
x=0:255;
n1=hist(LBP1(:),x);                
LBP_feature=n1;