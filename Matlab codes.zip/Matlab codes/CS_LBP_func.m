
%% *****************************%
% CS-Local Binary Pattern (LBP) 
% feature extraction

% Input image (I1)
%% ******************************%




function LBP_feature=CS_LBP_func(I1)

I2=double(I1);
[m,n]=size(I2);
for i=2:m-1
    for j=2:n-1
        block1(1:3,1:3)=I2(i-1:i+1,j-1:j+1);
        block=[block1(1,1)-block1(3,3),block1(1,2)-block1(3,2),block1(1,3)-block1(3,1),block1(2,1)-block1(2,3)];
        i1=1;
            for j1=1:4
                if block(i1,j1)>=0
                    s(i1,j1)=1;
                else
                    s(i1,j1)=0;
                end 
            end
        LBP1(i,j)=s(1,1)+2*s(1,2)+4*s(1,3)+8*s(1,4);
    end
end
x=0:15;
n1=hist(LBP1(:),x);                
LBP_feature=n1;
