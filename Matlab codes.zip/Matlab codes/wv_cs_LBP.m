clc
clear all

%%%%% 1- 3-level wavelet 2-extracting LBP from absolute of each subband

% Create an array of filenames that make up the image sequence
fileFolder = fullfile('C:','Documents and Settings','M','Desktop','New Folder (2)');
%('C:','Documents and Settings','Guest','Desktop','New Folder');
dirOutput = dir(fullfile(fileFolder,'*.png'));
fileNames = {dirOutput.name}';
numFrames = numel(fileNames);
k=0;
for smm =1:numFrames
    k=k+1;
    I1=imread(fileNames{smm});
    [A,B,C]=size(I1);

    if C~=1
        I1=rgb2gray(I1);
    end
    [cA,cH,cV,cD]=dwt2(I1,'db4');
    [cA1,cH1,cV1,cD1]=dwt2(cA,'db4');
    [cA2,cH2,cV2,cD2]=dwt2(cA1,'db4');

    M1=abs(cH);
    M2=abs(cV);
    M3=abs(cD);
    M4=abs(cH1);
    M5=abs(cV1);
    M6=abs(cD1);
    M7=abs(cH2);
    M8=abs(cV2);
    M9=abs(cD2);
    M10=abs(cA2);

    f1=CS_LBP_func(M1);
    f2=CS_LBP_func(M2);
    f3=CS_LBP_func(M3);
    f4=CS_LBP_func(M4);
    f5=CS_LBP_func(M5);
    f6=CS_LBP_func(M6);
    f7=CS_LBP_func(M7);
    f8=CS_LBP_func(M8);
    f9=CS_LBP_func(M9);
    f10=CS_LBP_func(M10);



    mask(k,1:160)=[f1,f2,f3,f4,f5,f6,f7,f8,f9,f10];

end